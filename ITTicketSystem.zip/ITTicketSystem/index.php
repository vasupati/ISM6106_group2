<!DOCTYPE HTML>

<?php

if(isset($_POST['login'])){
    $user = $_POST['username'];
    $password = $_POST['password'];
	if($user=="admin" && $password=="admin"){

		echo("username and password matched");
    }
    echo("error ! please try again!");

}
?>
<html lang="en" dir="ltr">
<head>

    <!--HEAD INCLUDE FILE START-->
    <?php

    include_once 'include/head.php';

    ?>

    <!--HEAD INCLUDE FILE END-->
</head>
<body>
<div class="limiter">
<div class="container-login100">
<div class="wrap-login100">
<div class="login100-pic js-tilt" data-tilt="" style="transform: perspective(300px) rotateX(0deg) rotateY(0deg); will-change: transform;">
<img src="img/logo.png" alt="Click it or Ticket System">
</div>

    <!--LOGING FORM INCLUDE FILE START-->
    <?php

    include_once 'include/login_form.php';

    ?>

    <!--LOGING FORM INCLUDE FILE END-->

</div>
</div>
</div>
    <!--FOOTER INCLUDE FILE START-->
    <?php

    include_once 'include/footer_scripts.php';

    ?>

    <!--FOOTER INCLUDE FILE END-->
