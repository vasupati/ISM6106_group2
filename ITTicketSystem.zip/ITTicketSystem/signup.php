<!DOCTYPE HTML>

<html lang="en" dir="ltr">
<head>

    <!--HEAD INCLUDE FILE START-->
    <?php

    include_once 'include/head.php';

    ?>

    <!--HEAD INCLUDE FILE END-->
</head>
<body>
<div class="limiter">
<div class="container-login100">
<div class="wrap-login100">
<div class="login100-pic js-tilt" data-tilt="" style="transform: perspective(300px) rotateX(0deg) rotateY(0deg); will-change: transform;">
<img src="img/logo.png" alt="Click it or Ticket System">
</div>

    <!--SIGNUP FORM INCLUDE FILE START-->
    <?php

    include_once 'include/signup_form.php';

    ?>

    <!--SIGNUP FORM INCLUDE FILE END-->

</div>
</div>
</div>
    <!--FOOTER INCLUDE FILE START-->
    <?php

    include_once 'include/footer_scripts.php';

    ?>

    <!--FOOTER INCLUDE FILE END-->
